*{
    margin:0;
    padding:0;
    font-family: Assistant,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;
    box-sizing: border-box;

} 
header{


    display:flex ;
    background-color:white;
    height: 80px;
    justify-content:space-between;
    align-items: center;
    border-bottom: 1px solid#605d5d;

}
.myntra_home{i

height: 36px;
width: 53px;
}
.logo_container{
    margin-left: 4%;

}
.action_bar{
    margin-left: 4%;
}
.nav_bar{
    display:flex;
    min-width: 500px;
    justify-content: space-between;
    align-items: center;
    
}
.nav_bar a{
    display: flex;
    justify-content: space-between;
    font-size: 14px;
    letter-spacing: .3px;
    color: #282c3f;
    font-weight: 700;
    text-decoration: none;
    padding:28px 0;
    box-sizing: content-box;

}
.nav_bar a:hover{
    border-bottom:4px solid#f54e77;
}
.nav_bar a sup{
    color:red;
    font-size: 10px;
}
.search_bar{
    display: flex;
    height: 40px;
    min-width: 200px;
    width: 30%;
    align-items: center;
    

}
.search_input{
    background-color: white;
    color: #696e79;
    flex-grow: 10;
    height: 40px;
    border-radius:0 4px 4px 0;
    border:0;


}
.search_icon{
    box-sizing: content-box;
    height: 20px;
    padding:10px;
    background-color: white;
    color: #696e79;
    font-weight: 300;
    border-radius:4px 0 0 4px;

}
.action_bar{
    display:flex;
    min-width: 200px;
    justify-content: space-evenly;
}
.action_container{
    display: flex;
    flex-direction: column;
    align-items: center;

}
/*main section*/
.banner_container{
    margin:40px 0;
}
.banner_image{
    width:100%;

}
.category_heading{
    text-transform: uppercase;
    color: #3e4152;
    letter-spacing: .15em;
    font-size: 1.8em;
    margin: 50px 0 10px 30px;
    max-height: 5em;
    font-weight: 700;

}
.category_item{
    display: flex;
    flex-wrap: wrap;
}
.offer_image{
    width: 236px;
    height:181px ;

}
.category_image{
    width: 236px;
    height:181px ;
}
.footer_container{
    color: #696b79;
    display: flex;
    font-size: 15px;
    text-decoration: none;
    padding-bottom: 5px;
    cursor: pointer;
    line-height: normal;
    justify-content: space-evenly;

}
.footer_column{
    display: flex;
    flex-direction: column;
}
.footer_column a{
    color: #696b79;
    display: flex;
    font-size: 15px;
    text-decoration: none;
    padding-bottom: 5px;
    

}
.copyright{
    color: #94969f;
    text-align: end;
    padding: 15px;
}
